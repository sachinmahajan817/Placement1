class User {
  String name = "";
  String phone = "";
  String email = "";
  String password = "";
  String rollno = "";
  String year = "";
  String branch = "";

  User(
    this.name,
    this.phone,
    this.email,
    this.password,
    this.rollno,
    this.year,
    this.branch,
  );
}
