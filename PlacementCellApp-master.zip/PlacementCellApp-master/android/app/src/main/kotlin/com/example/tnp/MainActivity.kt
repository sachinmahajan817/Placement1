package com.example.tnp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
